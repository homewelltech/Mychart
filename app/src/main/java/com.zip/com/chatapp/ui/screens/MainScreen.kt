package com.chatapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.chatapp.ui.nav.Screen
import com.chatapp.ui.screens.ChatScreen
import com.chatapp.ui.screens.FriendListScreen
import com.chatapp.ui.screens.SettingsScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Main") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar {
                val currentRoute = navController.currentBackStackEntry?.destination?.route
                listOf(Screen.Chat, Screen.FriendList, Screen.Settings).forEach { screen ->
                    print("进入main了")
//                    NavigationBarItem(
//                        icon = { /* 可根据需要添加图标 */ },
//                        label = { Text(screen.route.replaceFirstChar { it.uppercase() }) },
//                        selected = currentRoute == screen.route,
//                        onClick = { navController.navigate(screen.route) }
//                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Chat.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Screen.Chat.route) {
                ChatScreen(
                    messages = emptyList(),
                    onSendMessage = { /* 实现发送消息逻辑 */ }
                )
            }
            composable(Screen.FriendList.route) {
                FriendListScreen(friends = emptyList())
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }
}
