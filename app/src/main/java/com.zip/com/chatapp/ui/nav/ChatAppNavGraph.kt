package com.chatapp.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.chatapp.ui.screens.*

@Composable
fun ChatAppNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(onLoginSuccess = { navController.navigate(Screen.Main.route) })
        }
        composable(Screen.Register.route) {
            RegisterScreen(onRegisterSuccess = { navController.navigate(Screen.Login.route) })
        }
        composable(Screen.Main.route) { MainScreen(navController) }
        // 其他页面路由，可继续添加，如 ForgotPassword、ChatHistory 等
    }
}

// 封装路由定义
sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object Main : Screen("main")
    object Chat : Screen("chat")
    object FriendList : Screen("friendList")
    object Settings : Screen("settings")
    object ForgotPassword : Screen("forgotPassword")
    object ChatHistory : Screen("chatHistory")
}
