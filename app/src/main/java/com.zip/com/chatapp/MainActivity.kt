package com.chatapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.navigation.compose.rememberNavController
import com.chatapp.ui.nav.ChatAppNavGraph
import com.chatapp.ui.theme.ChatAppTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChatAppTheme {
                // 显式将 Activity 作为 ViewModelStoreOwner 提供给整个 Compose 树
                CompositionLocalProvider(androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner provides this) {
                    Surface(color = MaterialTheme.colorScheme.background) {
                        val navController = rememberNavController()
                        ChatAppNavGraph(navController = navController)
                    }
                }
            }
        }
    }
}
